(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,52683,e=>{"use strict";var t=e.i(43476),s=e.i(71645);let a=["全部","写作辅助","代码生成","数据分析","创意设计","学习教育","商业营销","日常效率"],r=[{id:"1",title:"高质量文章写作助手",category:"写作辅助",tags:["文章","博客","SEO"],description:"帮助你快速生成结构清晰、逻辑严密的优质文章，支持多种文体和风格切换。",prompt:`你是一位专业的内容创作者和写作教练。请根据以下要求帮我撰写一篇文章：

1. 主题：[在此输入主题]
2. 目标读者：[描述目标受众]
3. 文章风格：[正式/轻松/学术/叙事]
4. 字数要求：[大约字数]

请按以下结构输出：
- 引人入胜的标题
- 简洁有力的导语
- 3-5个分论点（每个配以案例或数据）
- 总结与行动号召

写作要求：
- 使用过渡句确保段落衔接自然
- 适当引用权威数据增强可信度
- 结尾给出明确的价值总结`,author:"写作达人",avatar:"✍️",likes:328,views:2890,createdAt:"2026-04-20",difficulty:"入门"},{id:"2",title:"全栈代码生成器",category:"代码生成",tags:["React","Node.js","全栈"],description:"从需求描述到完整代码实现，支持前后端全栈代码生成，附带最佳实践。",prompt:`你是一位资深全栈工程师。请根据以下需求生成代码：

项目需求：[描述你的项目需求]
技术栈：[React/Vue/Angular] + [Node.js/Python/Go]
数据库：[MongoDB/PostgreSQL/MySQL]

请输出：
1. 项目目录结构
2. 数据库模型/Schema设计
3. 后端API接口代码（含错误处理和参数验证）
4. 前端组件代码（含状态管理）
5. 关键配置文件

代码规范：
- 遵循SOLID原则
- 添加TypeScript类型定义
- 包含必要的错误边界处理
- 添加关键注释说明`,author:"代码大师",avatar:"💻",likes:512,views:4560,createdAt:"2026-04-18",difficulty:"进阶"},{id:"3",title:"数据分析报告生成",category:"数据分析",tags:["报告","可视化","洞察"],description:"将原始数据转化为专业分析报告，包含趋势分析、异常检测和行动建议。",prompt:`你是一位高级数据分析师。请对以下数据进行深度分析：

数据描述：[描述你的数据集]
分析目标：[你想了解什么]
时间范围：[数据的时间跨度]

请生成包含以下内容的分析报告：
1. 数据概览与基本统计
2. 关键趋势识别（同比/环比变化）
3. 异常值检测与原因推测
4. 细分维度交叉分析
5. 预测模型建议
6. 可视化图表建议（含图表类型和数据映射）
7. 核心洞察与行动建议

输出格式：
- 使用Markdown表格展示数据
- 关键发现用💡标注
- 风险提示用⚠️标注
- 机会点用🚀标注`,author:"数据猎手",avatar:"📊",likes:276,views:2100,createdAt:"2026-04-15",difficulty:"进阶"},{id:"4",title:"创意故事构思师",category:"创意设计",tags:["小说","剧本","创意"],description:"从一句话灵感到完整故事大纲，帮你构建引人入胜的叙事世界。",prompt:`你是一位才华横溢的创意写作导师。请帮我构思一个故事：

灵感种子：[一句话描述你的灵感]
故事类型：[科幻/奇幻/悬疑/爱情/现实主义]
目标篇幅：[短篇/中篇/长篇]

请输出：
1. 故事核心概念（一句话概括）
2. 世界观设定（3-5条核心规则）
3. 主要角色档案（含动机、弱点、成长弧线）
4. 三幕式结构大纲
5. 关键情节转折点（至少3个）
6. 主题与象征元素建议
7. 开篇第一段示范写作

创作原则：
- 确保每个角色都有清晰的动机
- 冲突要层层递进
- 结局既出人意料又在情理之中`,author:"灵感捕手",avatar:"🎨",likes:445,views:3200,createdAt:"2026-04-12",difficulty:"入门"},{id:"5",title:"个性化学习路径设计",category:"学习教育",tags:["学习计划","技能提升","课程"],description:"根据你的基础和目标，量身定制高效学习路径和时间规划。",prompt:`你是一位经验丰富的学习规划师。请帮我设计学习路径：

学习目标：[你想掌握的技能/知识]
当前水平：[零基础/入门/中级/高级]
可用时间：[每天/每周可投入的学习时间]
学习偏好：[视频/书籍/项目实战/混合]

请输出：
1. 技能树分解（核心技能→子技能→知识点）
2. 分阶段学习计划（每周具体任务）
3. 推荐学习资源（每个阶段3-5个精选资源）
4. 实践项目建议（由易到难，至少3个）
5. 自评检查点（每个阶段的学习成果检验）
6. 常见坑点预警
7. 时间分配建议（理论vs实践比例）

格式要求：
- 用时间线形式展示学习进度
- 标注每个阶段的预计耗时
- 区分必学和选学内容`,author:"学习向导",avatar:"📚",likes:389,views:2780,createdAt:"2026-04-10",difficulty:"入门"},{id:"6",title:"营销文案策划专家",category:"商业营销",tags:["文案","营销","品牌"],description:"打造高转化率营销文案，从品牌定位到传播策略一站式解决。",prompt:`你是一位顶级营销策划专家。请帮我策划营销方案：

产品/服务：[描述你的产品]
目标用户：[描述目标客户画像]
营销目标：[品牌曝光/获客/转化/复购]
预算范围：[大/中/小]

请输出：
1. 品牌定位语（3个版本：理性/感性/差异化）
2. 核心卖点提炼（最多3个）
3. 营销文案（适配不同渠道）：
   - 朋友圈/小红书种草文案
   - 公众号长文标题+导语
   - 短视频脚本（30s/60s版本）
   - 落地页文案
4. 传播策略与渠道建议
5. A/B测试建议
6. 转化漏斗设计

文案要求：
- 使用AIDA模型（注意→兴趣→欲望→行动）
- 每版文案包含明确的CTA
- 注入情感共鸣点`,author:"营销高手",avatar:"🚀",likes:423,views:3650,createdAt:"2026-04-08",difficulty:"进阶"},{id:"7",title:"智能日程管理助手",category:"日常效率",tags:["时间管理","效率","GTD"],description:"基于GTD方法论，帮你梳理任务、优化日程、提升执行力。",prompt:`你是一位GTD时间管理教练。请帮我整理和优化日程：

待办事项：[列出你所有待办事项]
优先级标准：[项目截止日期/影响力/紧急程度]
工作时段：[你的可用工作时间]
精力规律：[上午高效/下午稳定/晚上恢复]

请输出：
1. 任务分类（按GTD四象限法）
2. 每日时间块安排（具体到30分钟粒度）
3. 深度工作时段保护建议
4. 任务批处理建议
5. 每周复盘模板
6. 精力管理策略

排程原则：
- 重要任务安排在精力高峰期
- 相似任务合并处理
- 预留20%弹性时间
- 每90分钟安排一次休息`,author:"效率先锋",avatar:"⚡",likes:267,views:1920,createdAt:"2026-04-05",difficulty:"入门"},{id:"8",title:"API接口设计专家",category:"代码生成",tags:["RESTful","API","架构"],description:"遵循RESTful规范，设计规范的API接口文档，含认证、限流和版本管理。",prompt:`你是一位API架构师。请帮我设计API接口：

业务场景：[描述业务需求]
用户规模：[小/中/大]
技术偏好：[REST/GraphQL/gRPC]

请输出：
1. API设计规范
   - URL命名规范
   - 请求/响应格式
   - 错误码体系
2. 认证方案设计（JWT/OAuth2/API Key）
3. 接口列表（含完整文档）
   - 请求方法、路径、参数
   - 响应体结构
   - 状态码说明
4. 限流策略
5. 版本管理方案
6. 分页/过滤/排序设计

文档格式：
- 使用OpenAPI 3.0规范
- 每个接口附带请求/响应示例
- 标注必填/选填参数`,author:"架构师",avatar:"🔧",likes:356,views:2340,createdAt:"2026-04-03",difficulty:"高级"},{id:"9",title:"英文论文润色助手",category:"写作辅助",tags:["论文","学术","英文"],description:"专业的学术论文润色提示词，改善语法、提升表达、确保学术规范。",prompt:`你是一位资深的英文学术论文编辑。请帮我润色以下论文段落：

论文领域：[学科领域]
目标期刊：[期刊名称，如有]
润色重点：[语法/逻辑/表达/全部]

请按以下维度进行润色：
1. 语法修正（时态、主谓一致、冠词等）
2. 句式优化（避免冗长、提升简洁性）
3. 学术用语提升（替换口语化表达）
4. 逻辑衔接（增强段落间连贯性）
5. 语气调整（确保客观学术语气）

输出格式：
- 修改版本（标注所有改动）
- 修改说明（解释每处修改原因）
- 替代表达建议（提供2-3种不同表达方式）
- 常见问题提醒`,author:"学术编辑",avatar:"📝",likes:198,views:1560,createdAt:"2026-04-01",difficulty:"高级"},{id:"10",title:"UI/UX设计评审师",category:"创意设计",tags:["设计","UI","用户体验"],description:"从用户体验角度评审界面设计，提供专业的改进建议和设计规范。",prompt:`你是一位资深UI/UX设计顾问。请对以下界面设计进行评审：

产品类型：[Web/App/小程序]
目标用户：[描述用户群体]
设计截图/描述：[上传截图或描述界面]

请从以下维度评审：
1. 视觉层次（信息层级是否清晰）
2. 一致性（色彩、字体、间距是否统一）
3. 可用性（交互是否符合用户心智模型）
4. 无障碍（是否满足WCAG 2.1标准）
5. 响应式（不同屏幕适配情况）

输出内容：
- 总体评分（1-10分）
- 每个维度的详细评分和说明
- 关键问题列表（按严重程度排序）
- 改进建议（含具体的设计参数建议）
- 优秀设计亮点
- 参考案例推荐`,author:"设计鉴赏",avatar:"🎯",likes:312,views:2450,createdAt:"2026-03-28",difficulty:"进阶"},{id:"11",title:"SQL查询优化器",category:"数据分析",tags:["SQL","数据库","性能"],description:"分析并优化SQL查询语句，提供索引建议和执行计划分析。",prompt:`你是一位数据库性能优化专家。请帮我优化以下SQL查询：

数据库类型：[MySQL/PostgreSQL/SQL Server]
表结构：[描述相关表结构或提供DDL]
原始SQL：[粘贴你的SQL语句]
数据量级：[小/中/大/超大]
性能问题：[慢查询/高CPU/锁等待]

请输出：
1. 当前SQL问题分析
2. 优化后的SQL（标注所有改动）
3. 索引建议（含索引类型和字段）
4. 执行计划分析
5. 进一步优化建议（分区/分表/缓存等）
6. 性能对比预估

注意事项：
- 确保优化后结果集不变
- 考虑并发场景下的性能
- 评估索引对写入性能的影响`,author:"DBA专家",avatar:"🗄️",likes:234,views:1780,createdAt:"2026-03-25",difficulty:"高级"},{id:"12",title:"面试准备教练",category:"学习教育",tags:["面试","求职","准备"],description:"模拟真实面试场景，提供针对性问题和高分回答策略。",prompt:`你是一位专业的面试教练。请帮我准备面试：

应聘岗位：[目标职位]
公司类型：[大厂/创业公司/外企]
面试轮次：[HR面/技术面/总监面]
我的背景：[简要描述你的经历]

请输出：
1. 该岗位高频面试题Top10（含考察点分析）
2. 每道题的高分回答框架（STAR法则）
3. 行为面试应对策略
4. 技术面试知识点清单
5. 反问环节建议（5个高质量问题）
6. 面试前3天/1天/1小时checklist
7. 薪资谈判技巧

回答要求：
- 使用STAR法则组织回答
- 量化成果数据
- 展示成长思维
- 避免常见错误回答`,author:"面试教练",avatar:"💼",likes:467,views:4120,createdAt:"2026-03-22",difficulty:"入门"}],i={入门:"bg-emerald-100 text-emerald-700",进阶:"bg-amber-100 text-amber-700",高级:"bg-rose-100 text-rose-700"},l={写作辅助:"bg-blue-500",代码生成:"bg-violet-500",数据分析:"bg-cyan-500",创意设计:"bg-pink-500",学习教育:"bg-emerald-500",商业营销:"bg-orange-500",日常效率:"bg-yellow-500"};function n({card:e,onClick:a}){let[r,o]=(0,s.useState)(!1),[d,c]=(0,s.useState)(e.likes);return(0,t.jsxs)("div",{onClick:()=>a(e),className:"card-shimmer group relative bg-white rounded-2xl border border-gray-100 p-6 cursor-pointer transition-all duration-300 hover:shadow-lg hover:shadow-indigo-100/50 hover:-translate-y-1 hover:border-indigo-200",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,t.jsxs)("span",{className:`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium text-white ${l[e.category]||"bg-gray-500"}`,children:[(0,t.jsx)("span",{className:"w-1.5 h-1.5 rounded-full bg-white/60"}),e.category]}),(0,t.jsx)("span",{className:`px-2 py-0.5 rounded-md text-xs font-medium ${i[e.difficulty]}`,children:e.difficulty})]}),(0,t.jsx)("h3",{className:"text-lg font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition-colors line-clamp-1",children:e.title}),(0,t.jsx)("p",{className:"text-sm text-gray-500 mb-4 line-clamp-2 leading-relaxed",children:e.description}),(0,t.jsx)("div",{className:"flex flex-wrap gap-1.5 mb-4",children:e.tags.map(e=>(0,t.jsxs)("span",{className:"px-2 py-0.5 bg-gray-50 text-gray-500 rounded-md text-xs",children:["#",e]},e))}),(0,t.jsxs)("div",{className:"flex items-center justify-between pt-4 border-t border-gray-50",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("span",{className:"text-lg",children:e.avatar}),(0,t.jsx)("span",{className:"text-xs text-gray-400",children:e.author})]}),(0,t.jsxs)("div",{className:"flex items-center gap-3 text-xs text-gray-400",children:[(0,t.jsxs)("button",{onClick:e=>{e.stopPropagation(),o(!r),c(r?d-1:d+1)},className:`flex items-center gap-1 transition-colors ${r?"text-rose-500":"hover:text-rose-400"}`,children:[(0,t.jsx)("svg",{className:"w-4 h-4",fill:r?"currentColor":"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"})}),d]}),(0,t.jsxs)("span",{className:"flex items-center gap-1",children:[(0,t.jsxs)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:[(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 12a3 3 0 11-6 0 3 3 0 016 0z"}),(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"})]}),e.views]})]})]})]})}function o({card:e,onClose:a}){let[r,i]=(0,s.useState)(!1);if(!e)return null;let l=()=>{navigator.clipboard.writeText(e.prompt),i(!0),setTimeout(()=>i(!1),2e3)};return(0,t.jsxs)("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4",onClick:a,children:[(0,t.jsx)("div",{className:"absolute inset-0 bg-black/40 backdrop-blur-sm"}),(0,t.jsxs)("div",{className:"relative bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden shadow-2xl animate-fade-in-up",onClick:e=>e.stopPropagation(),children:[(0,t.jsxs)("div",{className:"sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-100 px-6 py-4 flex items-center justify-between z-10",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("span",{className:"text-2xl",children:e.avatar}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h2",{className:"text-xl font-bold text-gray-900",children:e.title}),(0,t.jsxs)("p",{className:"text-xs text-gray-400",children:[e.author," · ",e.createdAt]})]})]}),(0,t.jsx)("button",{onClick:a,className:"w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors text-gray-400 hover:text-gray-600",children:(0,t.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]}),(0,t.jsxs)("div",{className:"overflow-y-auto max-h-[calc(85vh-140px)] p-6",children:[(0,t.jsxs)("div",{className:"flex flex-wrap gap-2 mb-4",children:[(0,t.jsx)("span",{className:"px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-sm font-medium",children:e.category}),(0,t.jsx)("span",{className:`px-3 py-1 rounded-full text-sm font-medium ${"入门"===e.difficulty?"bg-emerald-50 text-emerald-600":"进阶"===e.difficulty?"bg-amber-50 text-amber-600":"bg-rose-50 text-rose-600"}`,children:e.difficulty}),e.tags.map(e=>(0,t.jsxs)("span",{className:"px-3 py-1 bg-gray-50 text-gray-500 rounded-full text-sm",children:["#",e]},e))]}),(0,t.jsx)("p",{className:"text-gray-600 mb-6 leading-relaxed",children:e.description}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsxs)("div",{className:"bg-gray-900 rounded-xl p-5 text-sm leading-relaxed",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 mb-3 pb-3 border-b border-gray-700",children:[(0,t.jsx)("span",{className:"w-3 h-3 rounded-full bg-red-500"}),(0,t.jsx)("span",{className:"w-3 h-3 rounded-full bg-yellow-500"}),(0,t.jsx)("span",{className:"w-3 h-3 rounded-full bg-green-500"}),(0,t.jsx)("span",{className:"ml-2 text-gray-500 text-xs",children:"Prompt"})]}),(0,t.jsx)("pre",{className:"text-gray-100 whitespace-pre-wrap font-mono text-sm leading-7",children:e.prompt})]}),(0,t.jsx)("button",{onClick:l,className:`absolute top-3 right-3 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${r?"bg-emerald-500 text-white":"bg-white/90 text-gray-600 hover:bg-white shadow-sm"}`,children:r?"✓ 已复制":"复制提示词"})]})]}),(0,t.jsxs)("div",{className:"sticky bottom-0 bg-white/80 backdrop-blur-md border-t border-gray-100 px-6 py-3 flex items-center justify-between",children:[(0,t.jsxs)("div",{className:"flex items-center gap-4 text-sm text-gray-400",children:[(0,t.jsxs)("span",{className:"flex items-center gap-1",children:[(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"})}),e.likes," 赞"]}),(0,t.jsxs)("span",{className:"flex items-center gap-1",children:[(0,t.jsxs)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:[(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 12a3 3 0 11-6 0 3 3 0 016 0z"}),(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"})]}),e.views," 浏览"]})]}),(0,t.jsx)("button",{onClick:l,className:"px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors",children:r?"已复制到剪贴板":"一键复制提示词"})]})]})]})}let d=["😊","😎","🤓","🧑‍💻","👩‍🎨","🧑‍🔬","🧑‍🏫","🧑‍🚀","🦊","🐱","🦁","🐻"];function c(){return d[Math.floor(Math.random()*d.length)]}function x(){let e=["快乐的","好奇的","冷静的","热情的","聪明的","勇敢的"],t=["探索者","学习者","创作者","思考者","实践者","观察者"];return`${e[Math.floor(Math.random()*e.length)]}${t[Math.floor(Math.random()*t.length)]}${Math.floor(100*Math.random())}`}function m(){let[e,a]=(0,s.useState)([]),[r,i]=(0,s.useState)(""),[l,n]=(0,s.useState)([]),[o,d]=(0,s.useState)(null),m=(0,s.useRef)(null),[g,h]=(0,s.useState)(!1),[u,p]=(0,s.useState)(""),f=(0,s.useCallback)(()=>{m.current?.scrollIntoView({behavior:"smooth"})},[]);(0,s.useEffect)(()=>{f()},[e,f]),(0,s.useEffect)(()=>{if(!g)return;let e=setInterval(()=>{n(e=>{let t=Math.random()>.3&&e.length<15,s=Math.random()>.7&&e.length>1;if(t){let t={id:`user-${Date.now()}`,name:x(),avatar:c(),joinedAt:new Date};return a(e=>[...e,{id:`sys-${Date.now()}`,username:"系统",avatar:"🤖",content:`${t.name} 加入了交流大厅`,timestamp:new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit"}),isSystem:!0}]),[...e,t]}if(s&&e.length>1){let t=e[Math.floor(Math.random()*e.length)];return t.id===o?.id?e:(a(e=>[...e,{id:`sys-${Date.now()}`,username:"系统",avatar:"🤖",content:`${t.name} 离开了交流大厅`,timestamp:new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit"}),isSystem:!0}]),e.filter(e=>e.id!==t.id))}return e})},8e3+12e3*Math.random());return()=>clearInterval(e)},[g,o?.id]);let b=()=>{let e=u.trim()||x(),t={id:`user-me-${Date.now()}`,name:e,avatar:c(),joinedAt:new Date};d(t),n([t]),h(!0),a([{id:"sys-welcome",username:"系统",avatar:"🤖",content:`欢迎 ${e} 加入 PromptHub 交流社区！在这里分享你的提示词使用心得，一起探索AI的无限可能。`,timestamp:new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit"}),isSystem:!0}])},j=()=>{if(!r.trim()||!o)return;let e={id:`msg-${Date.now()}`,username:o.name,avatar:o.avatar,content:r,timestamp:new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit"})};a(t=>[...t,e]),i("")};return g?(0,t.jsxs)("div",{className:"flex h-full bg-white rounded-2xl border border-gray-100 overflow-hidden",children:[(0,t.jsxs)("div",{className:"hidden lg:flex flex-col w-56 border-r border-gray-50 bg-gray-50/50",children:[(0,t.jsx)("div",{className:"p-4 border-b border-gray-100",children:(0,t.jsxs)("h3",{className:"text-sm font-semibold text-gray-700",children:["在线成员 · ",l.length]})}),(0,t.jsx)("div",{className:"flex-1 overflow-y-auto p-3 space-y-1",children:l.map(e=>(0,t.jsxs)("div",{className:`flex items-center gap-2.5 px-3 py-2 rounded-lg transition-colors ${e.id===o?.id?"bg-indigo-50":"hover:bg-white"}`,children:[(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)("span",{className:"text-lg",children:e.avatar}),(0,t.jsx)("span",{className:"absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-gray-50"})]}),(0,t.jsxs)("span",{className:`text-sm truncate ${e.id===o?.id?"text-indigo-600 font-medium":"text-gray-600"}`,children:[e.name,e.id===o?.id&&(0,t.jsx)("span",{className:"text-xs text-gray-400",children:"（我）"})]})]},e.id))})]}),(0,t.jsxs)("div",{className:"flex-1 flex flex-col",children:[(0,t.jsxs)("div",{className:"px-6 py-4 border-b border-gray-100 flex items-center justify-between",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h2",{className:"text-lg font-bold text-gray-900",children:"💬 实时交流大厅"}),(0,t.jsx)("p",{className:"text-xs text-gray-400 mt-0.5",children:"分享提示词技巧，探讨AI应用"})]}),(0,t.jsx)("div",{className:"flex items-center gap-2",children:(0,t.jsxs)("span",{className:"flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-xs font-medium",children:[(0,t.jsx)("span",{className:"w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"}),l.length," 人在线"]})})]}),(0,t.jsxs)("div",{className:"flex-1 overflow-y-auto p-6 space-y-4",children:[0===e.length&&(0,t.jsxs)("div",{className:"text-center py-16",children:[(0,t.jsx)("div",{className:"text-5xl mb-4",children:"💭"}),(0,t.jsx)("p",{className:"text-gray-400 text-sm",children:"暂无消息，快来发起第一个话题吧！"})]}),e.map(e=>(0,t.jsx)("div",{className:`animate-fade-in-up ${e.isSystem?"flex justify-center":"flex gap-3"}`,children:e.isSystem?(0,t.jsx)("div",{className:"px-4 py-2 bg-indigo-50 text-indigo-600 rounded-full text-xs font-medium",children:e.content}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"flex-shrink-0 w-9 h-9 flex items-center justify-center bg-gray-100 rounded-full text-lg",children:e.avatar}),(0,t.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,t.jsxs)("div",{className:"flex items-baseline gap-2 mb-1",children:[(0,t.jsx)("span",{className:`text-sm font-medium ${e.username===o?.name?"text-indigo-600":"text-gray-700"}`,children:e.username}),(0,t.jsx)("span",{className:"text-xs text-gray-300",children:e.timestamp})]}),(0,t.jsx)("div",{className:`inline-block px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${e.username===o?.name?"bg-indigo-600 text-white rounded-br-md":"bg-gray-50 text-gray-700 rounded-bl-md"}`,children:e.content})]})]})},e.id)),(0,t.jsx)("div",{ref:m})]}),(0,t.jsx)("div",{className:"p-4 border-t border-gray-100",children:(0,t.jsxs)("div",{className:"flex items-end gap-3",children:[(0,t.jsx)("div",{className:"flex-1 relative",children:(0,t.jsx)("textarea",{value:r,onChange:e=>i(e.target.value),onKeyDown:e=>{"Enter"!==e.key||e.shiftKey||(e.preventDefault(),j())},placeholder:"输入消息，Enter 发送...",rows:1,className:"w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-400 transition-all placeholder:text-gray-300",style:{maxHeight:"120px"}})}),(0,t.jsx)("button",{onClick:j,disabled:!r.trim(),className:"flex-shrink-0 w-11 h-11 flex items-center justify-center bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:bg-gray-200 disabled:text-gray-400 transition-all",children:(0,t.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 19l9 2-9-18-9 18 9-2zm0 0v-8"})})})]})})]})]}):(0,t.jsx)("div",{className:"flex h-full items-center justify-center bg-white rounded-2xl border border-gray-100",children:(0,t.jsxs)("div",{className:"text-center max-w-md mx-auto p-8",children:[(0,t.jsx)("div",{className:"w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-6 shadow-lg shadow-indigo-200",children:"💬"}),(0,t.jsx)("h2",{className:"text-2xl font-bold text-gray-900 mb-2",children:"加入实时交流大厅"}),(0,t.jsx)("p",{className:"text-gray-500 mb-8",children:"与其他提示词爱好者实时交流，分享心得与技巧"}),(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsx)("input",{type:"text",value:u,onChange:e=>p(e.target.value),onKeyDown:e=>"Enter"===e.key&&b(),placeholder:"输入你的昵称（可选，留空自动生成）",className:"w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-400 transition-all"}),(0,t.jsx)("button",{onClick:b,className:"w-full px-6 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors shadow-md shadow-indigo-200",children:"加入交流大厅"})]})]})})}function g({value:e,onChange:a}){let[r,i]=(0,s.useState)(!1);return(0,t.jsxs)("div",{className:`relative flex items-center transition-all duration-300 ${r?"scale-[1.02]":""}`,children:[(0,t.jsx)("svg",{className:`absolute left-4 w-5 h-5 transition-colors ${r?"text-indigo-500":"text-gray-300"}`,fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"})}),(0,t.jsx)("input",{type:"text",value:e,onChange:e=>a(e.target.value),onFocus:()=>i(!0),onBlur:()=>i(!1),placeholder:"搜索提示词、标签、分类...",className:`w-full pl-12 pr-4 py-3.5 bg-white border rounded-xl text-sm transition-all duration-300 outline-none ${r?"border-indigo-400 ring-4 ring-indigo-500/10 shadow-lg shadow-indigo-100/50":"border-gray-200 hover:border-gray-300"}`}),e&&(0,t.jsx)("button",{onClick:()=>a(""),className:"absolute right-4 w-5 h-5 flex items-center justify-center text-gray-300 hover:text-gray-500 transition-colors",children:(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]})}let h={全部:"🔥",写作辅助:"✍️",代码生成:"💻",数据分析:"📊",创意设计:"🎨",学习教育:"📚",商业营销:"🚀",日常效率:"⚡"};function u({categories:e,active:s,onChange:a}){return(0,t.jsx)("div",{className:"flex flex-wrap gap-2",children:e.map(e=>(0,t.jsxs)("button",{onClick:()=>a(e),className:`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${s===e?"bg-indigo-600 text-white shadow-md shadow-indigo-200":"bg-white text-gray-600 border border-gray-200 hover:border-indigo-200 hover:text-indigo-600 hover:bg-indigo-50"}`,children:[(0,t.jsx)("span",{children:h[e]||"📌"}),e]},e))})}e.s(["default",0,function(){let[e,i]=(0,s.useState)("全部"),[l,d]=(0,s.useState)(""),[c,x]=(0,s.useState)(null),[h,p]=(0,s.useState)("cards"),f=(0,s.useMemo)(()=>r.filter(t=>{let s="全部"===e||t.category===e,a=!l||t.title.toLowerCase().includes(l.toLowerCase())||t.description.toLowerCase().includes(l.toLowerCase())||t.tags.some(e=>e.toLowerCase().includes(l.toLowerCase()));return s&&a}),[e,l]);return(0,t.jsxs)("div",{className:"min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50/30",children:[(0,t.jsx)("header",{className:"sticky top-0 z-40 bg-white/70 backdrop-blur-xl border-b border-gray-100/80",children:(0,t.jsx)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,t.jsxs)("div",{className:"flex items-center justify-between h-16",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("div",{className:"w-9 h-9 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-lg shadow-lg shadow-indigo-200",children:"✦"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h1",{className:"text-lg font-bold text-gray-900 tracking-tight",children:"PromptHub"}),(0,t.jsx)("p",{className:"text-[10px] text-gray-400 -mt-0.5",children:"提示词学习 · 交流社区"})]})]}),(0,t.jsxs)("div",{className:"flex items-center gap-1 bg-gray-100/80 p-1 rounded-xl",children:[(0,t.jsx)("button",{onClick:()=>p("cards"),className:`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${"cards"===h?"bg-white text-indigo-600 shadow-sm":"text-gray-500 hover:text-gray-700"}`,children:"📋 知识卡片"}),(0,t.jsxs)("button",{onClick:()=>p("chat"),className:`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 relative ${"chat"===h?"bg-white text-indigo-600 shadow-sm":"text-gray-500 hover:text-gray-700"}`,children:["💬 交流社区",(0,t.jsx)("span",{className:"absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full animate-pulse"})]})]}),(0,t.jsxs)("div",{className:"hidden md:flex items-center gap-4 text-sm text-gray-400",children:[(0,t.jsxs)("span",{className:"flex items-center gap-1",children:[(0,t.jsx)("span",{className:"text-indigo-500 font-semibold",children:r.length}),"个提示词"]}),(0,t.jsx)("span",{className:"w-px h-4 bg-gray-200"}),(0,t.jsxs)("span",{className:"flex items-center gap-1",children:[(0,t.jsx)("span",{className:"w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"}),"7 人在线"]})]})]})})}),(0,t.jsx)("main",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:"cards"===h?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"mb-8",children:[(0,t.jsxs)("h2",{className:"text-3xl font-bold text-gray-900 mb-2",children:["探索优质",(0,t.jsx)("span",{className:"bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent",children:"提示词"}),"，释放 AI 潜能"]}),(0,t.jsx)("p",{className:"text-gray-500 text-lg",children:"精心整理的提示词知识库，涵盖写作、编程、数据分析等领域"})]}),(0,t.jsxs)("div",{className:"mb-8 space-y-4",children:[(0,t.jsx)(g,{value:l,onChange:d}),(0,t.jsx)(u,{categories:a,active:e,onChange:i})]}),(0,t.jsx)("div",{className:"mb-6 flex items-center justify-between",children:(0,t.jsxs)("p",{className:"text-sm text-gray-400",children:["找到"," ",(0,t.jsx)("span",{className:"text-indigo-600 font-medium",children:f.length})," ","个提示词"]})}),f.length>0?(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:f.map(e=>(0,t.jsx)(n,{card:e,onClick:x},e.id))}):(0,t.jsxs)("div",{className:"text-center py-20",children:[(0,t.jsx)("div",{className:"text-6xl mb-4",children:"🔍"}),(0,t.jsx)("h3",{className:"text-lg font-medium text-gray-600 mb-2",children:"没有找到匹配的提示词"}),(0,t.jsx)("p",{className:"text-sm text-gray-400",children:"试试调整搜索关键词或切换分类"})]})]}):(0,t.jsx)("div",{className:"h-[calc(100vh-160px)]",children:(0,t.jsx)(m,{})})}),(0,t.jsx)(o,{card:c,onClose:()=>x(null)})]})}],52683)}]);